package com.example.inventorytest;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class MainController {
    @FXML
    private TableView<Item> itemsTable;
    @FXML
    private TableColumn<Item, String> nameColumn;
    @FXML
    private TableColumn<Item, Integer> quantityColumn;
    @FXML
    private TableColumn<Item, Double> priceColumn;
    @FXML
    private TextField nameField;
    @FXML
    private TextField quantityField;
    @FXML
    private TextField priceField;

    private InventoryManager inventoryManager;

    public MainController() {
        this.inventoryManager = new InventoryManager("inventory.xlsx");
    }

    @FXML
    private void initialize() {
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        refreshTable();
    }

    @FXML
    private void addItem() {
        if (validateInput()) {
            String name = nameField.getText();
            int quantity = Integer.parseInt(quantityField.getText());
            double price = Double.parseDouble(priceField.getText());

            Item newItem = new Item(name, quantity, price);
            inventoryManager.addItem(newItem);
            refreshTable();
            clearFields();
        }
    }

    @FXML
    private void updateItem() {
        if (validateInput()) {
            String name = nameField.getText();
            int quantity = Integer.parseInt(quantityField.getText());
            double price = Double.parseDouble(priceField.getText());

            inventoryManager.updateItem(name, quantity, price);
            refreshTable();
            clearFields();
        }
    }

    @FXML
    private void viewItems() {
        refreshTable();
    }

    @FXML
    private void exit() {
        System.exit(0);
    }

    private void refreshTable() {
        ObservableList<Item> itemList = FXCollections.observableArrayList(inventoryManager.getItems());
        itemsTable.setItems(itemList);
    }

    private void clearFields() {
        nameField.clear();
        quantityField.clear();
        priceField.clear();
    }

    private boolean validateInput() {
        String name = nameField.getText();
        String quantityStr = quantityField.getText();
        String priceStr = priceField.getText();

        if (name == null || name.trim().isEmpty()) {
            showAlert("Error", "Name is required.");
            return false;
        }

        try {
            int quantity = Integer.parseInt(quantityStr);
            if (quantity <= 0) {
                showAlert("Error", "Quantity must be a positive integer.");
                return false;
            }
        } catch (NumberFormatException e) {
            showAlert("Error", "Quantity must be a valid integer.");
            return false;
        }

        try {
            double price = Double.parseDouble(priceStr);
            if (price <= 0) {
                showAlert("Error", "Price must be a positive number.");
                return false;
            }
        } catch (NumberFormatException e) {
            showAlert("Error", "Price must be a valid number.");
            return false;
        }

        return true;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}