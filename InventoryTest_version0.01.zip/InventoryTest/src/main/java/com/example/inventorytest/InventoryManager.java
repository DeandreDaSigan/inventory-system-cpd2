package com.example.inventorytest;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class InventoryManager {
    private List<Item> items;
    private String filePath;

    public InventoryManager(String filePath) {
        this.filePath = "data/inventory.xlsx";
        this.items = new ArrayList<>();
        loadItems();
    }

    private void loadItems() {
        try (FileInputStream file = new FileInputStream(new File(filePath));
             Workbook workbook = new XSSFWorkbook(file)) {

            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();

            // Skip header row
            if (rowIterator.hasNext()) {
                rowIterator.next();
            }

            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                Cell nameCell = row.getCell(0);
                Cell quantityCell = row.getCell(1);
                Cell priceCell = row.getCell(2);

                if (nameCell != null && quantityCell != null && priceCell != null) {
                    String name = nameCell.getStringCellValue();
                    int quantity = (int) quantityCell.getNumericCellValue();
                    double price = priceCell.getNumericCellValue();

                    items.add(new Item(name, quantity, price));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addItem(Item item) {
        items.add(item);
        saveItems();
    }

    public void updateItem(String name, int quantity, double price) {
        for (Item item : items) {
            if (item.getName().equalsIgnoreCase(name)) {
                item.setQuantity(quantity);
                item.setPrice(price);
                saveItems();
                return;
            }
        }
        System.out.println("Item not found.");
    }

    public void viewItems() {
        for (Item item : items) {
            System.out.println(item);
        }
    }

    private void saveItems() {
        try (Workbook workbook = new XSSFWorkbook();
             FileOutputStream fileOut = new FileOutputStream(filePath)) {

            Sheet sheet = workbook.createSheet("Inventory");

            // Create header row
            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("Name");
            headerRow.createCell(1).setCellValue("Quantity");
            headerRow.createCell(2).setCellValue("Price");

            // Populate data rows
            int rowNum = 1;
            for (Item item : items) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(item.getName());
                row.createCell(1).setCellValue(item.getQuantity());
                row.createCell(2).setCellValue(item.getPrice());
            }

            workbook.write(fileOut);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Item> getItems() {
        return items;
    }
}